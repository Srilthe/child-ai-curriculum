import numpy as np
def zscore_normalize(arr):
    arr = np.array(arr, dtype=float)
    return (arr - arr.mean())/arr.std()
