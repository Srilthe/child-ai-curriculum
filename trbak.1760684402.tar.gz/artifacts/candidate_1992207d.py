import json
def merge_json(path1,path2,outpath):
    with open(path1) as f1, open(path2) as f2:
        d1,d2=json.load(f1),json.load(f2)
    with open(outpath,'w') as f: json.dump({**d1,**d2},f)
