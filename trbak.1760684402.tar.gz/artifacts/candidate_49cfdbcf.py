from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
def train_logreg(X,y):
    model = LogisticRegression(max_iter=200).fit(X,y)
    return float(accuracy_score(y, model.predict(X)))
