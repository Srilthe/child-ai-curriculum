import matplotlib.pyplot as plt
def plot_hist(data, outpath):
    plt.hist(data); plt.savefig(outpath); return outpath
