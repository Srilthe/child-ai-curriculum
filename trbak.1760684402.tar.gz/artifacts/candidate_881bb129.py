def unique_word_count(path):
    with open(path) as f: return len(set(f.read().split()))
