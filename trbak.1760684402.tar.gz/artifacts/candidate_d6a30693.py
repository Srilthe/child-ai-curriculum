import pandas as pd
def count_rows(path): return len(pd.read_csv(path))
