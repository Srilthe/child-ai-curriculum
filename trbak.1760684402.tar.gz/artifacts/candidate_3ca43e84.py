def mean(lst): return sum(lst) / len(lst)
