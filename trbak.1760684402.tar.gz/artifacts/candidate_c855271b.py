import torch
def gpu_matrix_mul(A, B):
    A_gpu = torch.tensor(A, dtype=torch.float32).cuda()
    B_gpu = torch.tensor(B, dtype=torch.float32).cuda()
    result = torch.matmul(A_gpu, B_gpu)
    return result.cpu().tolist()
