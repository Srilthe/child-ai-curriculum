import matplotlib.pyplot as plt
def plot_series(data, outpath):
    plt.figure(); plt.plot(data); plt.savefig(outpath); return outpath